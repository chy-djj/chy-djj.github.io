# love_website

This web is for my lovely girlfriend. Happy one year!

**Coders can also be romantic! ^o^**

This project is based on several repositories on gihub. Welcome secondary development.

Demo address: [www.love.zhuyujie.org](http://love.zhuyujie.org)
(The domain will expire on 2017/3)
